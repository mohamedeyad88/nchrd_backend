import { createTheme } from "@mui/material/styles";
import { prefixer } from "stylis";
import rtlPlugin from "stylis-plugin-rtl";
import createCache from "@emotion/cache";

export const cacheRtl = createCache({
  key: "muirtl",
  stylisPlugins: [prefixer, rtlPlugin],
});

export const theme = createTheme({
  direction: "rtl",
  palette: {
    mode: "dark",
    primary: { main: "#D32F2F" },
    secondary: { main: "#4CAF50" },
    background: {
      default: "#101010",
      paper: "#1E1E1E",
    },
    text: {
      primary: "#ffffff",
      secondary: "#B0B0B0",
    },
  },

  typography: {
    fontFamily: "Cairo, sans-serif",
    allVariants: { color: "#fff" },
  },

  components: {
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: "#000",
          borderRight: "1px solid #333", // ✔ drawer يمين
          borderLeft: "none",
          direction: "rtl",               // ✔ منع عكس المحتوى
        },
      },
    },

    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: "#101010",
          borderBottom: "1px solid #333",
          boxShadow: "none",
        },
      },
    },
  },
});
