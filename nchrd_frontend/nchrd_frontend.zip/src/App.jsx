import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { CssBaseline, ThemeProvider } from '@mui/material';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { CacheProvider } from '@emotion/react';
import { cacheRtl, theme } from './theme';

// الصفحات والمكونات
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import Students from './pages/Students';
import Companies from './pages/Companies';
import Evaluations from './pages/Evaluations';
import TrainingDays from './pages/TrainingDays';
import Users from './pages/Users';
import Reports from './pages/Reports';
import Profile from './pages/Profile';

// حماية المسارات
const PrivateRoute = ({ children }) => {
  const token = localStorage.getItem('access_token');
  return token ? children : <Navigate to="/login" />;
};

export default function App() {

  useEffect(() => {
    document.body.dir = "rtl";
  }, []);

  return (
    <CacheProvider value={cacheRtl}>
      <ThemeProvider theme={theme}>
        
        <CssBaseline />

        <ToastContainer 
          rtl
          position="top-center"
          theme="dark"
          autoClose={3000}
        />

        <Router>
          <Routes>

            <Route path="/login" element={<Login />} />

            <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>

              <Route index element={<Home />} />

              <Route path="students" element={<Students />} />
              <Route path="companies" element={<Companies />} />
              <Route path="evaluations" element={<Evaluations />} />
              <Route path="training-days" element={<TrainingDays />} />
              <Route path="users" element={<Users />} />
              <Route path="managers" element={<Users />} />
              <Route path="reports" element={<Reports />} />
              <Route path="profile" element={<Profile />} />

            </Route>

          </Routes>
        </Router>

      </ThemeProvider>
    </CacheProvider>
  );
}
