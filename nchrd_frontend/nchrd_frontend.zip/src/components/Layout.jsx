import { useState } from 'react';
import { Outlet, useNavigate, useLocation, Link } from 'react-router-dom';
import { 
  Box, AppBar, Toolbar, Typography, Drawer, List, 
  ListItem, ListItemButton, ListItemText,  
  IconButton, Button 
} from '@mui/material';

import MenuIcon from '@mui/icons-material/Menu';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import BusinessIcon from '@mui/icons-material/Business';
import AssignmentIcon from '@mui/icons-material/Assignment';
import SchoolIcon from '@mui/icons-material/School';
import LogoutIcon from '@mui/icons-material/Logout';
import NotificationsIcon from '@mui/icons-material/Notifications';

const drawerWidth = 260;

const menuItems = [
  { text: 'لوحة التحكم', icon: <DashboardIcon />, path: '/' },
  { text: 'إدارة الوحدات', icon: <BusinessIcon />, path: '/companies' },
  { text: 'مديري الوحدات', icon: <PeopleIcon />, path: '/managers' },
  { text: 'إدارة المستخدمين', icon: <PeopleIcon />, path: '/users' },
  { text: 'تسعيد الطلاب', icon: <SchoolIcon />, path: '/students' },
  { text: 'التقارير والإعدادات', icon: <AssignmentIcon />, path: '/reports' },
];

export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const drawerContent = (
    <div style={{ direction: "rtl" }}>
      <Toolbar sx={{ justifyContent: 'center', minHeight: '80px !important' }}>
        <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#fff' }}>
          المركز الوطني
        </Typography>
      </Toolbar>
      
      <Box sx={{ px: 2, mb: 2 }}>
        <Button 
          fullWidth 
          variant="contained" 
          color="primary" 
          sx={{ justifyContent: 'flex-start', py: 1.5, fontWeight: 'bold' }}
          startIcon={<DashboardIcon />}
        >
          لوحة التحكم
        </Button>
      </Box>

      <Typography variant="caption" sx={{ px: 3, color: 'gray', display: 'block', mb: 1 }}>
        الإدارة المركزية
      </Typography>

      <List>
        {menuItems.slice(1).map((item) => (
          <ListItem key={item.text} disablePadding sx={{ mb: 0.5 }}>
            
            <ListItemButton 
              component={Link} 
              to={item.path}
              selected={location.pathname === item.path}
              sx={{ 
                mx: 1,
                borderRadius: 1,
                color: '#b0b0b0',

                display: 'flex',
                flexDirection: 'row-reverse',

                '&.Mui-selected': {
                  bgcolor: 'rgba(211, 47, 47, 0.1)',
                  color: 'primary.main',
                  borderRight: '4px solid #d32f2f',
                },

                '&:hover': {
                  bgcolor: 'rgba(255, 255, 255, 0.05)',
                  color: '#fff',
                },
              }}
            >

              {/* ⭐ النص شمال */}
              <ListItemText 
                primary={item.text}
                sx={{ textAlign: 'left', fontWeight: '500' }}
              />

              {/* ⭐ أيقونة يمين — بدون ListItemIcon */}
              <Box sx={{ color: 'inherit', display: 'flex', alignItems: 'center', pr: 1 }}>
                {item.icon}
              </Box>

            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <Box sx={{ display: 'flex' }} dir="rtl">

      <AppBar 
        position="fixed" 
        sx={{ 
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          mr: { sm: `${drawerWidth}px` },
          bgcolor: '#101010',
          borderBottom: '1px solid #333',
        }}
      >
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              color="inherit"
              onClick={() => setMobileOpen(!mobileOpen)}
              sx={{ ml: 2, display: { sm: 'none' } }}
            >
              <MenuIcon />
            </IconButton>

            <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
              المركز الوطني للتعليم والتدريب المزدوج
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <IconButton color="inherit">
              <NotificationsIcon />
            </IconButton>

            <Button 
              variant="contained" 
              color="primary"
              startIcon={<LogoutIcon />}
              onClick={handleLogout}
            >
              تسجيل الخروج
            </Button>
          </Box>

        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: drawerWidth, flexShrink: 0 }}>

        <Drawer
          variant="temporary"
          anchor="right"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { width: drawerWidth },
          }}
        >
          {drawerContent}
        </Drawer>

        <Drawer
          variant="permanent"
          anchor="right"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { width: drawerWidth },
          }}
          open
        >
          {drawerContent}
        </Drawer>

      </Box>

      <Box
        component="main"
        sx={{ 
          flexGrow: 1, 
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          mr: { sm: `${drawerWidth}px` },
          minHeight: '100vh',
          bgcolor: '#101010',
          color: '#fff'
        }}
      >
        <Toolbar />
        <Outlet />
      </Box>
    </Box>
  );
}
